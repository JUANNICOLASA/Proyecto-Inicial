/**
 * La clase Store representa una tienda en la ruta de seda.
 * Extiende la clase Rectangle para heredar sus propiedades visuales y de posicionamiento.
 * * @author Juan Nicolás Álvarez, Nicolas Sanchez
 * @version 1.0
 */
public class Store extends Rectangle {
    private int location;
    private int tenges;

    /**
     * Constructor para la clase Store.
     * Crea una nueva tienda con una ubicación y cantidad de dinero inicial.
     * * @param location La ubicación de la tienda en la ruta.
     * @param tenges La cantidad de dinero inicial de la tienda.
     */
    public Store(int location, int tenges) {
        super(location, 0, 5, 5); 
        this.location = location;
        this.tenges = tenges;
    }
    
    /**
     * Retorna la ubicación de la tienda.
     * @return La ubicación de la tienda como un entero.
     */
    public int getLocation() {
        return this.location;
    }
    
    /**
     * Retorna la cantidad de dinero que tiene la tienda.
     * @return La cantidad de dinero.
     */
    public int getTenges() {
        return this.tenges;
    }
    
}