import java.util.List;
import java.util.ArrayList;

/**
 * La clase SilkRoad simula una ruta de seda con robots y tiendas.
 * Actúa como el controlador principal, gestionando la creación y manipulación
 * de los objetos del simulador.
 * * @author Juan Nicolás Álvarez, Nicolas Sanchez
 * @version 1.0
 */
public class SilkRoad {
    private int longitud;
    private List<Store> stores;
    private List<Robot> robots;
    private int profit;
    private boolean isVisible;
    private boolean lastOperationOk;

    /**
     * Constructor para la clase SilkRoad.
     * Crea una nueva ruta de seda con la longitud especificada.
     * * @param longitud La longitud de la ruta.
     */
    public SilkRoad(int longitud) {
        this.longitud = longitud;
        this.stores = new ArrayList<>();
        this.robots = new ArrayList<>();
        this.profit = 0;
        this.isVisible = false;
        this.lastOperationOk = true;
    }

    /**
     * Coloca una nueva tienda en la ruta de seda.
     * * @param location La ubicación donde se colocará la tienda.
     * @param tenges La cantidad de dinero inicial que tendrá la tienda.
     */
    public void placeStore(int location, int tenges) {
        Store newStore = new Store(location, tenges);
        stores.add(newStore);
        this.lastOperationOk = true;
    }

    /**
     * Elimina una tienda de la ruta de seda por su ubicación.
     * * @param location La ubicación de la tienda a eliminar.
     */
    public void removeStore(int location) {
        for (Store store : stores) {
            if (store.getLocation() == location) {
                stores.remove(store);
                this.lastOperationOk = true;
                return;
            }
        }
        this.lastOperationOk = false;
    }
    
    /**
     * Coloca un nuevo robot en la ruta de seda.
     * * @param location La ubicación inicial del robot.
     */
    public void placeRobot(int location) {
        Robot newRobot = new Robot(location);
        robots.add(newRobot);
        this.lastOperationOk = true;
    }

    /**
     * Elimina un robot de la ruta de seda por su ubicación.
     * * @param location La ubicación del robot a eliminar.
     */
    public void removeRobot(int location) {
        for (Robot robot : robots) {
            if (robot.getLocation() == location) {
                robots.remove(robot);
                this.lastOperationOk = true;
                return;
            }
        }
        this.lastOperationOk = false;
    }

    /**
     * Mueve un robot una cantidad específica de metros.
     * * @param location La ubicación del robot que se va a mover.
     * @param meters La cantidad de metros que el robot se moverá.
     */
    public void moveRobot(int location, int meters) {
        for (Robot robot : robots) {
            if (robot.getLocation() == location) {
                robot.move(meters);
                this.lastOperationOk = true;
                return;
            }
        }
        this.lastOperationOk = false;
    }

    /**
     * Reabastece todas las tiendas en la ruta de seda.
     */
    public void resupplyStores() {
        for (Store store : stores) {
        }
        this.lastOperationOk = true;
    }

    /**
     * Retorna todos los robots a sus posiciones iniciales.
     */
    public void returnRobots() {
        for (Robot robot : robots) {
        }
        this.lastOperationOk = true;
    }

    /**
     * Reinicia la ruta de seda, restaurando tiendas y robots a su estado inicial y la ganancia a cero.
     */
    public void reboot() {
        this.profit = 0;
        for (Store store : stores) {
        }
        for (Robot robot : robots) {
        }
        this.lastOperationOk = true;
    }

    /**
     * Consulta las ganancias totales obtenidas hasta el momento.
     * * @return La cantidad total de dinero (tenges) ganados.
     */
    public int profit() {
        return this.profit;
    }

    /**
     * Consulta la información de todas las tiendas.
     * * @return Una matriz de enteros donde cada fila es [location, tenges].
     */
    public int[][] stores() {
        int[][] storeInfo = new int[stores.size()][2];
        for (int i = 0; i < stores.size(); i++) {
            storeInfo[i][0] = stores.get(i).getLocation();
            storeInfo[i][1] = stores.get(i).getTenges();
        }
        return storeInfo;
    }

    /**
     * Consulta la información de todos los robots.
     * * @return Una matriz de enteros donde cada fila es [location, tenges].
     */
    public int[][] robots() {
        int[][] robotInfo = new int[robots.size()][2];
        for (int i = 0; i < robots.size(); i++) {
            robotInfo[i][0] = robots.get(i).getLocation();
            robotInfo[i][1] = robots.get(i).getTenges();
        }
        return robotInfo;
    }

    /**
     * Hace que el simulador sea visible.
     */
    public void makeVisible() {
        this.isVisible = true;
        for (Store store : stores) {
            store.makeVisible();
        }
        for (Robot robot : robots) {
            robot.makeVisible();
        }
    }

    /**
     * Hace que el simulador sea invisible.
     */
    public void makeInvisible() {
        this.isVisible = false;
        for (Store store : stores) {
            store.makeInvisible();
        }
        for (Robot robot : robots) {
            robot.makeInvisible();
        }
    }

    /**
     * Termina el simulador, eliminando todos los objetos y la ruta de seda.
     */
    public void finish() {
        this.stores.clear();
        this.robots.clear();
        this.lastOperationOk = true;
    }
    
    /**
     * Indica si la última operación se realizó con éxito.
     * * @return Verdadero si la última operación fue exitosa, falso en caso contrario.
     */
    public boolean ok() {
        return this.lastOperationOk;
    }
}