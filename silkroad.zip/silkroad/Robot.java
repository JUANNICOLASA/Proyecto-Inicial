/**
 * La clase Robot representa un robot en la ruta de seda.
 * Extiende la clase Triangle para heredar sus propiedades visuales y de movimiento.
 * * @author Juan Nicolás Álvarez, Nicolas Sanchez
 * @version 1.0
 */
public class Robot extends Triangle {
    private int location;
    private int tenges;

    /**
     * Constructor para la clase Robot.
     * Crea un nuevo robot en la ubicación inicial especificada.
     * Los robots inician con 0 tenges.
     * * @param location La ubicación inicial del robot.
     */
    public Robot(int location) {
        super(location, 0, 10, 10); 
        this.location = location;
        this.tenges = 0;
    }
    
    /**
     * Retorna la ubicación actual del robot.
     * @return La ubicación del robot como un entero.
     */
    public int getLocation() {
        return this.location;
    }
    
    /**
     * Retorna la cantidad de dinero que tiene el robot.
     * @return La cantidad de dinero.
     */
    public int getTenges() {
        return this.tenges;
    }

    /**
     * Mueve el robot una cantidad de metros.
     * @param meters La cantidad de metros a mover.
     */
    public void move(int meters) {
        this.location += meters;
        // Se asume que moveHorizontal() de la clase Triangle mueve el objeto visual.
        this.moveHorizontal(meters);
    }
}